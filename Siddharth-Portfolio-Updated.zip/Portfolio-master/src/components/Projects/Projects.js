import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import ProjectCard from "./ProjectCards";
import Particle from "../Particle";

// Reusing existing placeholder images (you can replace with your own screenshots later)
import editor from "../../Assets/Projects/codeEditor.png";
import leaf from "../../Assets/Projects/leaf.png";

function Projects() {
  return (
    <Container fluid className="project-section">
      <Particle />
      <Container>
        <h1 className="project-heading">
          Featured <strong className="purple">Projects</strong>
        </h1>
        <p style={{ color: "white" }}>
          A few projects from my resume. (Add your GitHub/demo links when ready.)
        </p>

        <Row style={{ justifyContent: "center", paddingBottom: "10px" }}>
          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={leaf}
              isBlog={false}
              title="Recover Ease – Lost Item Recovery (Deep Image Search)"
              description="Designed an AI-powered lost item recovery system using TensorFlow/Keras for deep image search, with OpenCV-based similarity matching. Built the backend with Django + SQLite including image uploads, authentication, and lost/found item management."
              ghLink="https://github.com/your-github-username/recover-ease"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={editor}
              isBlog={false}
              title="Healthcare Management Database System"
              description="Built a centralized relational database for hospital operations (patients, appointments, treatments, billing). Designed a normalized ER model, automated scheduling/billing via forms + SQL, and validated system logic using Python/Jupyter."
              ghLink="https://github.com/your-github-username/healthcare-db-system"
            />
          </Col>
        </Row>
      </Container>
    </Container>
  );
}

export default Projects;
