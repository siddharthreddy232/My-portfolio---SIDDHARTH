import React from "react";
import Card from "react-bootstrap/Card";
import { ImPointRight } from "react-icons/im";

function AboutCard() {
  return (
    <Card className="quote-card-view">
      <Card.Body>
        <blockquote className="blockquote mb-0">
          <p style={{ textAlign: "justify" }}>
            Hi! I’m <span className="purple">Siddharth Reddy Maddi</span>.
            <br />
            I’m currently pursuing an <span className="purple">M.S. in Business Analytics</span> at{" "}
            <span className="purple">California State University, Northridge</span> (GPA: 3.6).
            <br />
            Previously, I worked as a <span className="purple">Data Analyst Intern</span> at{" "}
            <span className="purple">IT Technology (Hyderabad)</span>, where I automated analysis with Python, built Tableau/Power BI dashboards, and wrote SQL to speed up reporting.
            <br />
            <br />
            Here are a few things I enjoy working on:
          </p>

          <ul>
            <li className="about-activity">
              <ImPointRight /> Data cleaning, analysis, and storytelling 📊
            </li>
            <li className="about-activity">
              <ImPointRight /> Machine learning & deep learning projects 🤖
            </li>
            <li className="about-activity">
              <ImPointRight /> Building dashboards (Tableau / Power BI) 📈
            </li>
          </ul>

          <p style={{ color: "rgb(155 126 172)" }}>
            "Turn data into decisions."
          </p>
          <footer className="blockquote-footer">Siddharth</footer>
        </blockquote>
      </Card.Body>
    </Card>
  );
}

export default AboutCard;
